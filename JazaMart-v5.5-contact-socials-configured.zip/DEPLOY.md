# Deploy JazaMart online

## Recommended: Render

This repository includes `render.yaml` and a production `Dockerfile`.

1. Push this project to a GitHub repository.
2. In Render, create a Blueprint and select that repository.
3. Render will create the JazaMart web service and PostgreSQL database from `render.yaml`.
4. Set `FRONTEND_URL` to the public JazaMart URL if you want to restrict CORS; otherwise it can be left blank for this single-service deployment.
5. Deploy and open the generated `onrender.com` URL.

The web service automatically builds the React frontend and serves it from Express. `AUTO_INIT_DB=true` applies the schema on startup, and `/api/health` is the health check.

## M-Pesa

The current checkout supports the M-Pesa payment method at the application level, but a real M-Pesa transaction still requires your Safaricom Daraja credentials and a public HTTPS callback. Do not commit those secrets to GitHub.


## Production notes

- The Docker build uses `npm install` rather than `npm ci` because this release intentionally ships without lockfiles; Render can install directly from the package manifests.
- The Blueprint provisions a Free Render Postgres database in Singapore for a Kenya-first deployment. Render currently documents Free Postgres as 1 GB and 30-day lifetime; it is suitable for testing, not long-term production.
- For real production use, upgrade the Postgres instance before launch and configure real payment credentials separately.
