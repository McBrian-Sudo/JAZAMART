import fs from 'node:fs';

const required = ['react', 'react-dom', 'vite', '@vitejs/plugin-react'];
const missing = required.filter(x => !fs.existsSync(`node_modules/${x}`));

if (missing.length) {
  console.error('JazaMart frontend dependencies are not installed.');
  console.error('Missing:', missing.join(', '));
  console.error('Run: npm install');
  process.exit(2);
}

console.log('All frontend build dependencies are installed.');
